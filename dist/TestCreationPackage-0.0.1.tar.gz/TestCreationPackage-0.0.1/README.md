# TestCreationPackage
Formation à la création d'un package python
